import React, { useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import './login.css';
import axios from 'axios';
import {useContext} from 'react';
import {UserContext} from './UserContext'
function Login ()
{
	const [username,setUsername] = useState('');
	const [password,setPassword] = useState('');
	const {user, setUser}=useContext(UserContext);
	const history=useHistory();
	useEffect(() => {
		async  function fetchData() {
			const request = await axios.get('http://localhost:4000/runtime/news')
			console.log(request.data)
			return request
		}
		fetchData()
	},[])
	const resetForm=()=>{
		
		setUsername("");
		setPassword("");
	}
	const handleClick = (evt) => {
		evt.preventDefault()
		async  function fetchData() {
			const request = await axios.post('http://localhost:4000/runtime/login', {
				'username' : username,
				'password':password
		})
			if(request &&!request.data.success)
			{

				alert("Some or all of the inputs are invalid. Please try again");
				resetForm();

			}
			else if (request &&request.data.success)
			{
				let msg= "Welcome "+request.data.username+"!";
				alert(msg)
				console.log(request.data);
				setUser(request.data);
				if(request.data.type=="seller")
				{
				return history.push('/sellermiddashboard');
				}
				if(request.data.type=="buyer")
				{
				return history.push('/buyerdashboard');
				}
			}
			return request
		}
		fetchData()
	}

	return (
		<div className= "loginForm">
		<form>
		<label>
		Enter Email
		<br/>
      	<input
	      	type='text'
	      	placeholder='Email'
	      	value={username}
	      	onChange={event => setUsername(event.target.value)}
      	/>
      	</label>
      	<br/>
      	<label>
      	Enter Password
      	<br/>
      	<input
	      	type='password'
	      	placeholder='Password'
	      	value={password}
	      	onChange={event => setPassword(event.target.value)}
      	/>
      	</label>
      	<br/>
      	<button type='submit' onClick={handleClick}>Submit</button>

      	
      	</form>
      </div>

		);
} 
export default Login;
