import logo from './logo.svg';
import './App.css';
import Login from './screens/login';
import Register from './screens/newregister';
import BuyerRegister from './screens/buyerRegister';
import BuyerHistory from './screens/BuyerHistory';
import BuyerDashboard from './screens/BuyerDashboard';
import SellerRegister from './screens/sellerRegister';
import {Route,Switch,Redirect} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import SellerDashboard from './screens/SellerDash';
import SellerMidDash from './screens/SellerMidDash';
import Listing from './screens/listproducts';

import NavBar from './NavBar2';
import BuyerNav from './screens/BuyerNav';
import {UserContext} from './screens/UserContext';
import React, { useState,useMemo,useEffect} from 'react';

function App() {

 const [user, setUser]=useState(-1);
 const providerValue= useMemo(  () => ({user,setUser}) , [user,setUser]);
  return (
  <>
  <UserContext.Provider value={providerValue}>
	{user==-1 ? <NavBar/> : <BuyerNav/>}
      <Switch>
	 
    	<Route exact path ='/'component={Login}/>
    	<Route exact path='/register' component={Register} />
    	<Route path='/register/buyer' component={BuyerRegister} />
    	<Route path='/register/seller' component={SellerRegister} />
		<Route exact path='/buyerdashboard' component={BuyerDashboard} />
		<Route exact path='/buyerdashboard/history' component={BuyerHistory} />
		<Route exact path='/sellermiddashboard' component={SellerMidDash} />
		<Route exact path='/sellerdashboard/postproduct' component={SellerDashboard} />
		<Route exact path='/sellerdashboard/listproducts' component={Listing} />
	  
     </Switch>
	  </UserContext.Provider>
    
	</>
  );
}

export default App;
