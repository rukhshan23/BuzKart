function SellerDash(props)
{
	return(

		<div>
		<h1> SELLER DASHBOARD </h1> 
		<p> Email: {props.username}</p>
		</div>
	);
}
export default SellerDash;
