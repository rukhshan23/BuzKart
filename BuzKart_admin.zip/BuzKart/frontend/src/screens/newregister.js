import React, { useState, useEffect} from 'react';

import axios from 'axios';
import Select from 'react-select';
import {NavLink,Redirect,Route,Switch} from 'react-router-dom';
import buyerRegister from './buyerRegister';
import sellerRegister from './sellerRegister';


function Register(){
	return(
		<div className="NavBar">

			<NavLink activeClassName="active_class" to="/register/buyer"> Create a Buyer Account</NavLink>
			<NavLink activeClassName="active_class" to="/register/seller"> Create a Seller Account</NavLink>

		</div>
		);

}
export default Register;
