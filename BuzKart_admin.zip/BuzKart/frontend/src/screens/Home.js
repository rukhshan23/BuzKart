import React from 'react';
import {NavLink} from 'react-router-dom';

const Home=()=>{
	return(
	
		<div className="Nav">
		<h1> BuzKart.pk! </h1>
			<NavLink activeClassName="active_class" to="/navbar">
				<h2>Click here to navigate!</h2>
			</NavLink>

		</div>
		);
}


export default Home;
