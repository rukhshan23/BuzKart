import React, { useState, useEffect} from 'react';
//import './login.css';
import axios from 'axios';
import {Route, Switch} from "react-router-dom";
import {Link,Redirect} from 'react-router-dom';
import { useHistory } from "react-router-dom";

function AdminDash()
{
    const history = useHistory();
    const handleClick1 = (evt) => {
        return(
        history.push("/approveprod")
		);
    }
    const handleClick2 = (evt) => {
        return(
        history.push("/trendseller")
		);
    }
	return(
        <>
	
		<h1> ADMIN DASHBOARD </h1> 
		
        <div className="FrontAdmin">
        <button type='submit' onClick={handleClick1} >Approve Products</button>
        <button type='submit' onClick={handleClick2}>View Trends</button>
        </div>
        </>
		   
	);
}
export default AdminDash;