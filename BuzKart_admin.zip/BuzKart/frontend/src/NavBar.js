import React from 'react';
import {NavLink} from 'react-router-dom';

const Nav=()=>{
	return(
	
		<div className="Nav">
			<NavLink activeClassName="active_class" to="/login">
				<h2>Login?</h2>
			</NavLink>
			<NavLink activeClassName="active_class" to="/register">
				<h2>Sign up?</h2>
			</NavLink>

		</div>
		);
}
export default Nav;